# This is one copy of your fleet

In the app, open System status and choose Restore.
